$(document).ready(function () {

$(".accordion > li > span").click(function() {
    $(this).toggleClass("active").next('div').slideToggle(250)
    .closest('li').siblings().find('span').removeClass('active').next('div').slideUp(250);
});
	
});

$(window).scroll(function() {
	// For Sticky Navbar
    if ($(window).scrollTop() > 300) { 
        $('.header-area').addClass('fixed_header');
    } else {
        $('.header-area').removeClass('fixed_header');
    }
    if ($(window).scrollTop() > 400) {
        $('.header-area').addClass('stky');
    } else {
        $('.header-area').removeClass('stky');
    }
});


/****************************/
let SwiperTop = new Swiper('.swiper-partner', {
    spaceBetween: 30,
    centeredSlides: true,
    speed: 6000,
    autoplay: {
        delay: 1,
    },
    loop: true,
    slidesPerView:'9',
    allowTouchMove: false,
    disableOnInteraction: true,
    breakpoints: {
		240: {
		  slidesPerView: 3,
		  spaceBetween: 20,
		},
		992: {
		  slidesPerView: 6,
		  spaceBetween: 25,
	    },
        992: {
            slidesPerView: 9,
            spaceBetween: 30,
        },
    },
});


var swiper = new Swiper('.memories-slider  .swiper-container', {
	slidesPerView: 2.2,
	loop:true,
	spaceBetween: 20,
	centeredSlides: true,

	breakpoints: {
		240: {
		  slidesPerView: 1,
		  spaceBetween: 20,
		},
		992: {
		  slidesPerView: 2.5,
		  spaceBetween: 25,
	    },
    },
});
